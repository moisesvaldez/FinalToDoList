package erleb.com.finaltodolist;

import android.content.DialogInterface;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewStructure;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    DBHelper dbHelper;
    ArrayAdapter<String> mAdapter;
    ListView listaTareas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);
        listaTareas = (ListView) findViewById(R.id.listaTareas);

        cargarListaTareas();
    }

    private void cargarListaTareas() {
        ArrayList<String> lstTareas = dbHelper.getListaTareas();
        if (mAdapter == null) {
            mAdapter = new ArrayAdapter<String>(this, R.layout.tarea_item, R.id.tvNombreTarea, lstTareas);
            listaTareas.setAdapter(mAdapter);
        } else{
            mAdapter.clear();
            mAdapter.addAll(lstTareas);
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
//        Drawable icon = menu.getItem(0).getIcon();
//        icon.mutate();
//        icon.setColorFilter(getResources().getColor(android.R.color.white, PorterDuff.Mode.);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_agregarTarea:
                final EditText tareaEditText = new EditText(this);
                AlertDialog dialog = new AlertDialog.Builder(this)
                        .setTitle("Agregar Nueva Tarea")
                        .setMessage("¿Qué desea hacer?")
                        .setView(tareaEditText)
                        .setPositiveButton("Agregar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String tarea = String.valueOf(tareaEditText.getText());
                                dbHelper.insertarNuevaTarea(tarea);
                                cargarListaTareas();
                            }
                        })
                        .setNegativeButton("Cancelar", null)
                        .create();
                dialog.show();
        }
        return super.onOptionsItemSelected(item);
    }

    public void borrarTarea(View v){
        View parent = (View) v.getParent();
        TextView tareaTextView = (TextView) findViewById(R.id.tvNombreTarea);
        String tarea = String.valueOf(tareaTextView.getText());
        dbHelper.borrarTarea(tarea);
        cargarListaTareas();
    }
}
